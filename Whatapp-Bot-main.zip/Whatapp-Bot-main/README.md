<div class = "repo" align = "center">
 
<a href = "#">
<img sr<div class = "repo" align = "center">
 
<a href = "#">
<img src = "chanu-deta/Picsart_24-08-16_14-40-03-866.jpg"  width="300" height="300">
</img>
 <p align="center">
  <a href="#"><img src="http://readme-typing-svg.herokuapp.com?color=ff00ab&center=true&vCenter=true&multiline=false&lines=CHANU+WHATSAPP+BOT" alt="">
</p>
    <p align="center">
<a href="#"><img title="Creator" src="https://img.shields.io/badge/Creator-Mrvisal-red.svg?style=for-the-badge&logo=github"></a>
     
</p>
<p align="center">
<a href="https://github.com/chanu19-v?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/darkmakerofc?color=green&style=flat-square"></a>
<a href="https://github.com/darkmakerofc/QueenElisa/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/darkmakerofc/QueenElisa?color=white&style=flat-square"></a>
<a href="https://github.com/darkmakerofc/QueenElisa/network/members"><img title="Forks" src="https://img.shields.io/github/forks/darkmakerofc/QueenElisa?color=yellow&style=flat-square"></a>
<a href="https://github.com/darkmakerofc/QueenElisa/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/darkmakerofc/QueenElisa?label=Watchers&color=red&style=flat-square"></a>
<a href="https://github.com/darkmakerofc/QueenElisa"><img title="Size" src="https://img.shields.io/github/repo-size/darkmakerofc/QueenElisa?style=flat-square&color=darkred"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https://github.com/darkmakerofc/QueenElisa/hit-counter&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2304FF00&title=hits&edge_flat=false"/></a>
<a href="https://github.com/darkmakerofc/QueenElisa/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained-No-red.svg"></a>&nbsp;&nbsp;
</p>
</a>
</div> 

<br>
<br>

💡 `This bot is created using` **[Baileys](https://github.com/WhiskeySockets/Baileys)**

<br>
<br>

### Please Read !
Chanu MD is a whatsapp bot created by mr visal ( darkmakerofc ) & CHANUCODERS TEAM using baileys web api. Do not use this bot in a way that will cause trouble to others. 
We are not responsible for any problems caused by your use of this!

 ### `VERSION : 1.0.1 - V`
 `Last Update : ` _2024-08-16_ | 

## Deployment Methods
---
1. ***Get [`SESSION ID`](https://suhail-md-vtsf.onrender.com/)  by scanning QR code. `Whatapp>Three dots>Linked Devices`***
   
2.  ***Deploy on [`HEROKU`](https://suhail-web.vercel.app//deploy?platform=heroku)***
4.  ***Deploy on [`Replit`](https://suhail-web.vercel.app/deploy?platform=replit)***  
5.  ***Deploy on [`Koyeb`](https://suhail-web.vercel.app/deploy?platform=koyeb)***
6.  ***Deploy on [`Glitch`](https://suhail-web.vercel.app/deploy?platform=glitch)***
7.  ***Deploy on [`CodeSpace`](https://suhail-web.vercel.app/deploy?platform=codespace)***
8. ***Deploy on [`Render`](https://suhail-web.vercel.app/deploy?platform=render)***
9. ***Deploy on [`Railway`](https://suhail-web.vercel.app/deploy?platform=railway)***
##



---

## Authors


## Thanks to


## Feedback
If you have any feedback, please reach out to us at Visalchanuka2015@gmail.com

## Support
If you need help, Join chanu md bot whtsapp support chat [w.me/chanumdBotsupport](Message chanu on WhatsApp. https://wa.me/message/JZGVWF6QKKPXK1)
</br></br></br>
 <p align="center"> CHANUCODERS - CHANU MD | 2024 </p>c = "chanu-deta/Picsart_24-08-16_14-40-03-866.jpg"  width="300" height="300">
</img>
 <p align="center">
  <a href="#"><img src="http://readme-typing-svg.herokuapp.com?color=ff00ab&center=true&vCenter=true&multiline=false&lines=CHANU+WHATSAPP+BOT" alt="">
</p>
    <p align="center">
<a href="#"><img title="Creator" src="https://img.shields.io/badge/Creator-Mrvisal-red.svg?style=for-the-badge&logo=github"></a>
     
</p>
<p align="center">
<a href="https://github.com/chanu19-v?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/darkmakerofc?color=green&style=flat-square"></a>
<a href="https://github.com/darkmakerofc/QueenElisa/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/darkmakerofc/QueenElisa?color=white&style=flat-square"></a>
<a href="https://github.com/darkmakerofc/QueenElisa/network/members"><img title="Forks" src="https://img.shields.io/github/forks/darkmakerofc/QueenElisa?color=yellow&style=flat-square"></a>
<a href="https://github.com/darkmakerofc/QueenElisa/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/darkmakerofc/QueenElisa?label=Watchers&color=red&style=flat-square"></a>
<a href="https://github.com/darkmakerofc/QueenElisa"><img title="Size" src="https://img.shields.io/github/repo-size/darkmakerofc/QueenElisa?style=flat-square&color=darkred"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https://github.com/darkmakerofc/QueenElisa/hit-counter&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2304FF00&title=hits&edge_flat=false"/></a>
<a href="https://github.com/darkmakerofc/QueenElisa/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained-No-red.svg"></a>&nbsp;&nbsp;
</p>
</a>
</div> 

<br>
<br>

💡 `This bot is created using` **[Baileys](https://github.com/WhiskeySockets/Baileys)**

<br>
<br>

### Please Read !
Chanu MD is a whatsapp bot created by mr visal ( darkmakerofc ) & CHANUCODERS TEAM using baileys web api. Do not use this bot in a way that will cause trouble to others. 
We are not responsible for any problems caused by your use of this!

 ### `VERSION : 1.0.1 - V`
 `Last Update : ` _2024-08-16_ | 

## Deployment Methods
---
1. ***Get [`SESSION ID`](https://suhail-md-vtsf.onrender.com/)  by scanning QR code. `Whatapp>Three dots>Linked Devices`***
   
2.  ***Deploy on [`HEROKU`](https://suhail-web.vercel.app//deploy?platform=heroku)***
4.  ***Deploy on [`Replit`](https://suhail-web.vercel.app/deploy?platform=replit)***  
5.  ***Deploy on [`Koyeb`](https://suhail-web.vercel.app/deploy?platform=koyeb)***
6.  ***Deploy on [`Glitch`](https://suhail-web.vercel.app/deploy?platform=glitch)***
7.  ***Deploy on [`CodeSpace`](https://suhail-web.vercel.app/deploy?platform=codespace)***
8. ***Deploy on [`Render`](https://suhail-web.vercel.app/deploy?platform=render)***
9. ***Deploy on [`Railway`](https://suhail-web.vercel.app/deploy?platform=railway)***
##



---

## Authors


## Thanks to


## Feedback
If you have any feedback, please reach out to us at Visalchanuka2015@gmail.com

## Support
If you need help, Join chanu md bot whtsapp support chat [w.me/chanumdBotsupport](Message chanu on WhatsApp. https://wa.me/message/JZGVWF6QKKPXK1)
</br></br></br>
 <p <div class = "repo" align = "center">
 
<a href = "#">
<img sr<div class = "repo" align = "center">
 
<a href = "#">
<img src = "chanu-deta/Picsart_24-08-16_14-40-03-866.jpg"  width="300" height="300">
</img>
 <p align="center">
  <a href="#"><img src="http://readme-typing-svg.herokuapp.com?color=ff00ab&center=true&vCenter=true&multiline=false&lines=CHANU+WHATSAPP+BOT" alt="">
</p>
    <p align="center">
<a href="#"><img title="Creator" src="https://img.shields.io/badge/Creator-Mrvisal-red.svg?style=for-the-badge&logo=github"></a>
     
</p>
<p align="center">
<a href="https://github.com/chanu19-v?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/darkmakerofc?color=green&style=flat-square"></a>
<a href="https://github.com/darkmakerofc/QueenElisa/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/darkmakerofc/QueenElisa?color=white&style=flat-square"></a>
<a href="https://github.com/darkmakerofc/QueenElisa/network/members"><img title="Forks" src="https://img.shields.io/github/forks/darkmakerofc/QueenElisa?color=yellow&style=flat-square"></a>
<a href="https://github.com/darkmakerofc/QueenElisa/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/darkmakerofc/QueenElisa?label=Watchers&color=red&style=flat-square"></a>
<a href="https://github.com/darkmakerofc/QueenElisa"><img title="Size" src="https://img.shields.io/github/repo-size/darkmakerofc/QueenElisa?style=flat-square&color=darkred"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https://github.com/darkmakerofc/QueenElisa/hit-counter&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2304FF00&title=hits&edge_flat=false"/></a>
<a href="https://github.com/darkmakerofc/QueenElisa/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained-No-red.svg"></a>&nbsp;&nbsp;
</p>
</a>
</div> 

<br>
<br>

💡 `This bot is created using` **[Baileys](https://github.com/WhiskeySockets/Baileys)**

<br>
<br>

### Please Read !
Chanu MD is a whatsapp bot created by mr visal ( darkmakerofc ) & CHANUCODERS TEAM using baileys web api. Do not use this bot in a way that will cause trouble to others. 
We are not responsible for any problems caused by your use of this!

 ### `VERSION : 1.0.1 - V`
 `Last Update : ` _2024-08-16_ | 

## Deployment Methods
---
1. ***Get [`SESSION ID`](https://suhail-md-vtsf.onrender.com/)  by scanning QR code. `Whatapp>Three dots>Linked Devices`***
   
2.  ***Deploy on [`HEROKU`](https://suhail-web.vercel.app//deploy?platform=heroku)***
4.  ***Deploy on [`Replit`](https://suhail-web.vercel.app/deploy?platform=replit)***  
5.  ***Deploy on [`Koyeb`](https://suhail-web.vercel.app/deploy?platform=koyeb)***
6.  ***Deploy on [`Glitch`](https://suhail-web.vercel.app/deploy?platform=glitch)***
7.  ***Deploy on [`CodeSpace`](https://suhail-web.vercel.app/deploy?platform=codespace)***
8. ***Deploy on [`Render`](https://suhail-web.vercel.app/deploy?platform=render)***
9. ***Deploy on [`Railway`](https://suhail-web.vercel.app/deploy?platform=railway)***
##



---

## Authors


## Thanks to


## Feedback
If you have any feedback, please reach out to us at Visalchanuka2015@gmail.com

## Support
If you need help, Join chanu md bot whtsapp support chat [w.me/chanumdBotsupport](Message chanu on WhatsApp. https://wa.me/message/JZGVWF6QKKPXK1)
</br></br></br>
 <p align="center"> CHANUCODERS - CHANU MD | 2024 </p>c = "chanu-deta/Picsart_24-08-16_14-40-03-866.jpg"  width="300" height="300">
</img>
 <p align="center">
  <a href="#"><img src="http://readme-typing-svg.herokuapp.com?color=ff00ab&center=true&vCenter=true&multiline=false&lines=CHANU+WHATSAPP+BOT" alt="">
</p>
    <p align="center">
<a href="#"><img title="Creator" src="https://img.shields.io/badge/Creator-Mrvisal-red.svg?style=for-the-badge&logo=github"></a>
     
</p>
<p align="center">
<a href="https://github.com/chanu19-v?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/darkmakerofc?color=green&style=flat-square"></a>
<a href="https://github.com/darkmakerofc/QueenElisa/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/darkmakerofc/QueenElisa?color=white&style=flat-square"></a>
<a href="https://github.com/darkmakerofc/QueenElisa/network/members"><img title="Forks" src="https://img.shields.io/github/forks/darkmakerofc/QueenElisa?color=yellow&style=flat-square"></a>
<a href="https://github.com/darkmakerofc/QueenElisa/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/darkmakerofc/QueenElisa?label=Watchers&color=red&style=flat-square"></a>
<a href="https://github.com/darkmakerofc/QueenElisa"><img title="Size" src="https://img.shields.io/github/repo-size/darkmakerofc/QueenElisa?style=flat-square&color=darkred"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https://github.com/darkmakerofc/QueenElisa/hit-counter&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2304FF00&title=hits&edge_flat=false"/></a>
<a href="https://github.com/darkmakerofc/QueenElisa/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained-No-red.svg"></a>&nbsp;&nbsp;
</p>
</a>
</div> 

<br>
<br>

💡 `This bot is created using` **[Baileys](https://github.com/WhiskeySockets/Baileys)**

<br>
<br>

### Please Read !
Chanu MD is a whatsapp bot created by mr visal ( darkmakerofc ) & CHANUCODERS TEAM using baileys web api. Do not use this bot in a way that will cause trouble to others. 
We are not responsible for any problems caused by your use of this!

 ### `VERSION : 1.0.1 - V`
 `Last Update : ` _2024-08-16_ | 

## Deployment Methods
---
1. ***Get [`SESSION ID`](https://suhail-md-vtsf.onrender.com/)  by scanning QR code. `Whatapp>Three dots>Linked Devices`***
   
2.  ***Deploy on [`HEROKU`](https://suhail-web.vercel.app//deploy?platform=heroku)***
4.  ***Deploy on [`Replit`](https://suhail-web.vercel.app/deploy?platform=replit)***  
5.  ***Deploy on [`Koyeb`](https://suhail-web.vercel.app/deploy?platform=koyeb)***
6.  ***Deploy on [`Glitch`](https://suhail-web.vercel.app/deploy?platform=glitch)***
7.  ***Deploy on [`CodeSpace`](https://suhail-web.vercel.app/deploy?platform=codespace)***
8. ***Deploy on [`Render`](https://suhail-web.vercel.app/deploy?platform=render)***
9. ***Deploy on [`Railway`](https://suhail-web.vercel.app/deploy?platform=railway)***
##



---

## Authors


## Thanks to


## Feedback
If you have any feedback, please reach out to us at Visalchanuka2015@gmail.com

## Support
If you need help, Join chanu md bot whtsapp support chat [w.me/chanumdBotsupport](Message chanu on WhatsApp. https://wa.me/message/JZGVWF6QKKPXK1)
</br></br></br>
 <p align="center"> CHANUCODERS - CHANU MD | 2024 </p>

align="center"> CHANUCODERS - CHANU MD | 2024 </p>


